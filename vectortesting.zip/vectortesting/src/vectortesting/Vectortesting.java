/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vectortesting;

/**
 *
 * @author estefania
 */
public class Vectortesting {

    /**
     * @param args the command line arguments
     */
    @SuppressWarnings("empty-statement")
    public static void main(String[] args) {
 
    int vector[]={1,2,3,4,5,6,7,8,9,0,11,12,1,14,115,16,17,18,19,23};
   
//        mostrarVector(vector);
//       int mayor= mayorValor(vector);
//       int menor= menorValor(vector);
//        System.out.println("");
//        System.out.println(menor);
//        System.out.println(mayor);
    }
//método para encontrar el valor mas alto del vector
    public static int mayorValor(int vector[]){
int mayor=0; 
        for (int i = 0; i < vector.length; i++) {
            if (i==0) {
                mayor=vector[i];
            } else {
                
                if (mayor<vector[i]) {
                    
                    mayor=vector[i];
                    
                }
            }
 
            
        }



return mayor;
    
       
    }
    //método para calcular el menor de un vector
    
    
    public static int menorValor(int vector[]){
int menor=0; 
        for (int i = 0; i < vector.length; i++) {
            if (i==0) {
                menor=vector[i];
            } else {
                
                if (menor>vector[i]) {
                    
                    menor=vector[i];
                    
                }
            }
 
            
        }



return menor;
    
       
    }    
    //método para mostrar vector
    
    public static void mostrarVector(int vector[]){
        System.out.println("-- vector --");
        for (int i = 0; i < vector.length; i++) {
            System.out.print(vector[i]+"  ");
        }
   
    }
    
    
}




