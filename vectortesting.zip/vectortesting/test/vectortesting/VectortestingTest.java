/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vectortesting;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author estefania
 */
public class VectortestingTest {
    
    public VectortestingTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of main method, of class Vectortesting.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        Vectortesting.main(args);
        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
    }


    /**
     * Test of mayorValor method, of class Vectortesting.
     */
    @Test
    public void testMayorValor() {
        System.out.println("mayorValor");
        int[] vector = {3,4,5,6,8,5,3,4,54,77,6,5,3,4,43,54,65,76,6};
        Vectortesting instance = new Vectortesting();
        int expResult = 77;
        int result = instance.mayorValor(vector);
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
    //    fail("The test case is a prototype.");
    }

    /**
     * Test of menorValor method, of class Vectortesting.
     */
    @Test
    public void testMenorValor() {
        System.out.println("menorValor");
        int[] vector = {3,4,5,6,8,5,3,4,54,665,77,6,5,3,4,43,54,65,76,6};
        Vectortesting instance = new Vectortesting();
        int expResult = 3;
        int result = instance.menorValor(vector);
        assertEquals(expResult, result);
        //  fail("The test case is a prototype.");
    }
//NO SE ME OCURRE COMO TESTEAR ALGO QUE SE MUESTRA. :((:(:(:(:(
    /**
     * Test of mostrarVector method, of class Vectortesting.
     */
//    @Test
//    public void testMostrarVector() {
//        System.out.println("mostrarVector");
//        int[] vector = null;
//        Vectortesting instance = new Vectortesting();
//        instance.mostrarVector(vector);
//        // TODO review the generated test code and remove the default call to fail.
//        fail("The test case is a prototype.");
//    }
    
}
